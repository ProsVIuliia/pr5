# pr4

### *Учебный проект от [Яндекс.Практикум](https://practicum.yandex.ru/web/)*

## Описание проекта
Проект создан JavaScript

## Стек технологий:
- HTML5;
- CSS3;
- Методология БЭМ;
- JavaScript;
- Вёрстка по макету из Figma.

## Изучены:
- Javascript,
- Адаптивный интерфейс для разных устройств.

Ссылка на проект: 
https://prosviuliia.github.io/pr4/